integramultiple <- function(n, a, b, fun){
  funx <- function(x){
    return
  }
}